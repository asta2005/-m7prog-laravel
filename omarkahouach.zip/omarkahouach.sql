-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: mariadb
-- Gegenereerd op: 03 okt 2024 om 13:15
-- Serverversie: 11.5.2-MariaDB-ubu2404
-- PHP-versie: 8.2.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `omarkahouach`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `artist`
--

CREATE TABLE `artist` (
  `id` int(11) NOT NULL,
  `datum` int(25) NOT NULL,
  `artist` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Gegevens worden geëxporteerd voor tabel `artist`
--

INSERT INTO `artist` (`id`, `datum`, `artist`) VALUES
(1, 2000, 'Rustage'),
(2, 2000, 'the_doors'),
(3, 2000, 'Claude_Monet'),
(4, 2000, 'Ella_Fitzgerald\r\n');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `genre`
--

CREATE TABLE `genre` (
  `id` int(11) NOT NULL,
  `datum` int(11) NOT NULL,
  `genre` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Gegevens worden geëxporteerd voor tabel `genre`
--

INSERT INTO `genre` (`id`, `datum`, `genre`) VALUES
(1, 2000, 'rock'),
(2, 2000, 'rap'),
(3, 2000, 'rythem'),
(4, 2000, 'jazz');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `muziek`
--

CREATE TABLE `muziek` (
  `id` int(11) NOT NULL,
  `datum` int(24) NOT NULL,
  `artist` int(11) NOT NULL,
  `genre` int(11) NOT NULL,
  `fotos` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Gegevens worden geëxporteerd voor tabel `muziek`
--

INSERT INTO `muziek` (`id`, `datum`, `artist`, `genre`, `fotos`) VALUES
(1, 2000, 1, 2, 'https://images.genius.com/4216893ad194adf9863d7025e815318f.288x288x1.jpg'),
(2, 2000, 2, 1, 'https://upload.wikimedia.org/wikipedia/commons/6/60/Doors_electra_publicity_photo.JPG'),
(3, 2000, 3, 3, 'https://lh4.googleusercontent.com/proxy/wSrIYY7clwFaegb6T32yyCyRxZrdUB8GHb4T3nZ3_O3UZ43x_VEZgE36-tMsoLSZPxWpCF4OJlcZv21EGHIX7s4gBQrTz5K6Gr6dnYH7xz_77uVXT_A'),
(4, 2000, 4, 4, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRO40R6ORT_B1IDYxMAEdbNatfgnCD75bW6Rw&s');

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `artist`
--
ALTER TABLE `artist`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `genre`
--
ALTER TABLE `genre`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `muziek`
--
ALTER TABLE `muziek`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fork1` (`genre`),
  ADD KEY `frok` (`artist`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `artist`
--
ALTER TABLE `artist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT voor een tabel `genre`
--
ALTER TABLE `genre`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT voor een tabel `muziek`
--
ALTER TABLE `muziek`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Beperkingen voor geëxporteerde tabellen
--

--
-- Beperkingen voor tabel `muziek`
--
ALTER TABLE `muziek`
  ADD CONSTRAINT `fork1` FOREIGN KEY (`genre`) REFERENCES `genre` (`id`),
  ADD CONSTRAINT `frok` FOREIGN KEY (`artist`) REFERENCES `artist` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
